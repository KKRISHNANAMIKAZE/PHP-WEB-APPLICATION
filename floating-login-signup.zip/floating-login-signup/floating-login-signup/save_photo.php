<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the image data from the POST request
    $imageData = $_POST['image'];

    // Generate a unique identifier (you may use your custom logic)
    $customId = uniqid();

    // Create a folder for the custom_id if it doesn't exist
    $folderPath = "C:/Users/artha/Music/{$customId}";
    if (!file_exists($folderPath)) {
        mkdir($folderPath, 0777, true);
    }

    // Save the image to the custom_id folder
    $imageName = "{$customId}_photo.jpg";
    $filePath = "{$folderPath}/{$imageName}";

    // Decode the base64 image data and save it to the file
    $imageData = str_replace('data:image/jpeg;base64,', '', $imageData);
    $imageData = str_replace(' ', '+', $imageData);
    $decodedImage = base64_decode($imageData);
    file_put_contents($filePath, $decodedImage);

    // Respond to the client
    echo "Photo saved successfully!";
} else {
    // Handle invalid requests
    http_response_code(400);
    echo "Invalid request method";
}
?>
