<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event QR Code Scanner</title>
    <script src="https://rawgit.com/EddieLa/BarcodeReader/master/dist/barcode-reader.min.js"></script>
</head>
<body>

<div id="uploadOption">
    <!-- Default to "Upload Images" -->
    <label for="eventImages">Upload Images:</label>
    <input type="file" id="eventImages" name="eventImages[]" accept="image/*" multiple>
</div>

<!-- Toggle Upload Option Button -->
<button type="button" onclick="toggleUploadOption()">Toggle Upload Option</button>

<script>
    function toggleUploadOption() {
        // Your code to toggle upload option
    }

    // Assume you have a function to generate the QR code with event details
    function generateQRCode(details) {
        // Your code to generate QR code (you can use a library like qrcode.js)
        // Example:
        const qrCodeData = "Event: " + details.eventName + " Date: " + details.eventDate;
        const qrCodeElement = document.createElement("img");
        qrCodeElement.src = "data:image/png;base64," + btoa(qrCodeData);
        document.body.appendChild(qrCodeElement);
    }

    // Assume you have a function to handle image detection
    function detectImages() {
        // Your code to open the camera and detect images (using a library like barcode-reader.js)
        // Example:
        const video = document.createElement("video");
        document.body.appendChild(video);

        const codeReader = new ZXing.BrowserQRCodeReader();
        codeReader.decodeFromVideoDevice(undefined, 'video')
            .then(result => {
                // Handle the result (in this case, log the result)
                console.log(result);
            })
            .catch(err => {
                console.error(err);
            });
    }

    // Example: Generate QR code when the page loads
    const eventDetails = {
        eventName: "Wedding",
        eventDate: "2.10.2024"
    };
    generateQRCode(eventDetails);

    // Example: Start image detection when the page loads
    detectImages();
</script>

</body>
</html>
