<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login & Registration Form</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700,800&display=swap" rel="stylesheet">
  <style>
    body {
      background-image: url('images/camera.png');
      background-size: cover;
      background-position: center;
      font-family: 'Nunito', sans-serif;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .cont {
      background-color: rgba(255, 255, 255, 0.8);
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    /* Add more styles as needed for the form, sub-cont, and other elements */
  </style>
</head>
<body>
  <div class="cont">
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      include('login-registration.php');
    }
    ?>
    <!-- Your existing HTML content -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="form sign-in">
      <h2>Sign In</h2>
      <label>
        <span>Email Address</span>
        <input id="name" type="email" name="email">
      </label>
      <label>
        <span>Password</span>
        <input id="pwd" type="password" name="password">
      </label>
      <button class="submit" type="submit" name="signin">Sign In</button>
      <p class="forgot-pass">Forgot Password?</p>

      <div class="social-media">
        <ul>
          <li><img src="images/google.png"></li>
        </ul>
      </div>
    </form>

    <div class="sub-cont" style="display:block">
      <div class="img">
        <div class="img-text m-up">
          <h2>New here?</h2>
          <p>Sign up and discover a great amount of new opportunities!</p>
        </div>
        <div class="img-text m-in">
          <h2>One of us?</h2>
          <p>If you already have an account, just sign in. We've missed you!</p>
        </div>
        <div class="img-btn">
          <span class="m-up">Sign Up</span>
          <span class="m-in">Sign In</span>
        </div>
      </div>

      <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="form sign-up">
        <h2>Sign Up</h2>
        <label>
          <span>Name</span>
          <input type="text" name="name">
        </label>
        <label>
          <span>Email</span>
          <input id="signup_email" type="email" name="signup_email">
        </label>
        <label>
          <span>Password</span>
          <input id="signup_password" type="password" name="signup_password">
        </label>
        <label>
          <span>Confirm Password</span>
          <input id="signup_confirm_password" type="password" name="signup_confirm_password">
        </label>
        <button type="submit" class="submit" name="signup">Sign Up Now</button>
      </form>
    </div>
  </div>
  <script type="text/javascript" src="script.js"></script>
</body>
</html>