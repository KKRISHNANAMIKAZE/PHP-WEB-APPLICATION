<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Page Title</title>
    <style>
       body {
            background-image: url('images/camera1.jpg');
            background-size: cover;
            font-family: Arial, sans-serif;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            background-color: rgba(0, 0, 0, 0.5);
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .navbar h1 {
            margin: 0;
        }

        .navbar a, .navbar button {
            text-decoration: none;
            color: #fff;
            margin: 0 15px;
            font-weight: bold;
            background: none;
            border: none;
            cursor: pointer;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-content {
            text-align: center;
            padding: 20px;
            border-radius: 10px;
            background-color: rgba(255, 255, 255, 0.8);
            margin-bottom: 20px;
        }

        .features, .demo, .about, .create-event-form {
            padding: 15px 30px;
            margin: 10px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            width: 100%;
            display: block;
            color: #fff;
            text-align: center;
            transition: background-color 0.3s ease;
        }

        .about {
            background-color: #e74c3c;
        }

        .features {
            background-color: #3498db;
        }

        .demo {
            background-color: #2ecc71;
        }

        .create-event-form {
            background-color: #e67e22;
        }

        .my-event-button {
            background-color: #8e44ad; /* Attractive color for MyEvent button */
        }

        .content-section {
            margin-top: 20px;
            padding: 20px;
            border-radius: 10px;
            text-align: left;
            background-color: #fff;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            text-align: left;
        }

        label {
            display: block;
            margin: 10px 0;
            color: #333;
        }

        input, select {
            width: calc(100% - 20px);
            padding: 10px;
            margin: 5px 0;
            box-sizing: border-box;
        }

        button {
            background-color: #e67e22;
            color: #fff;
            padding: 15px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            width: 100%;
            display: block;
            transition: background-color 0.3s ease;
        }

        button:hover, .navbar a:hover, .features:hover, .demo:hover, .about:hover, .create-event-form:hover, .my-event-button:hover {
            background-color: #d35400;
        }
    </style>
</head>
<body>

<div class="container">

    <!-- Navigation -->
    <div class="navbar">
        <?php
        // Replace database connection details with your own
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "photos";

        // Start the session
        session_start();

        // Check if the user is logged in
        if(isset($_SESSION['user_id'])) {
            // Get the user ID from the session
            $userId = $_SESSION['user_id'];

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch name from the database based on the user ID
            $sql = "SELECT name FROM login WHERE id = $userId";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $name = $row["name"];
                echo '<h1 id="name">Welcome ' . $name . '</h1>';
            } else {
                echo '<h1 id="name">Default Name</h1>'; // Provide a default name or handle accordingly
            }

            // Close the database connection
            $conn->close();
        } else {
            // Handle the case where the user is not logged in
            echo '<h1 id="name">Default Name</h1>';
        }
        ?>
        <div>
            <a href="#">Home</a>
            <a href="my_event.html" class="my-event-button">MyEvent</a>
            <a href="create_event.html">CreateEvent</a>
            <a href="#">Domains</a>
        </div>
    </div>

    <!-- About Section -->
    <div class="main-content">
        <div class="about">About</div>
        <div class="content-section about">
            <h2>About</h2>
            <p>Our image recognition platform utilizes advanced AI algorithms to analyze and recognize faces in uploaded images. We prioritize user privacy and data security, ensuring a seamless and secure experience for all our users.</p>
        </div>
    </div>

    <!-- Features Section -->
    <div class="main-content">
        <div class="features">Features</div>
        <div class="content-section features">
            <h2>Features</h2>
            <ul>
                <li>Face recognition technology</li>
                <li>Image categorization</li>
                <li>User-friendly image upload interface</li>
                <li>Secure and private data handling</li>
            </ul>
        </div>
    </div>

    <!-- Demo Section -->
    <div class="main-content">
        <div class="demo">Demo</div>
        <div class="content-section demo">
            <h2>Demo</h2>
            <p>Watch the demo below to see how our image recognition platform works:</p>
            <!-- Placeholder video -->
            <iframe width="100%" height="315" src="https://www.youtube.com/embed/Sv_eXJYbBMw?rel=0" frameborder="0" allowfullscreen></iframe>
        </div>
    </div>

</div>

</body>
</html>
