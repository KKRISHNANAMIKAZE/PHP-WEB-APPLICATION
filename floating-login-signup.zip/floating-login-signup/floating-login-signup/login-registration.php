<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "photos";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

if (isset($_POST['signin'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, custom_id, name, email, password FROM login WHERE email=?");

    if (!$stmt) {
        die("Error in SQL query: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();

    if ($stmt->error) {
        die("Error executing SQL query: " . $stmt->error);
    }

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['custom_id'] = $row['custom_id'];
            $_SESSION['user_name'] = $row['name'];
            header("Location: first.php");
            exit();
        } else {
            echo "Invalid email or password";
        }
    } else {
        echo "Invalid email or password";
    }
} elseif (isset($_POST['signup'])) {
    $name = $_POST['name'];
    $email = $_POST['signup_email'];
    $password = $_POST['signup_password'];

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO login (name, email, password) VALUES (?, ?, ?)");

    if (!$stmt) {
        die("Error in SQL query: " . $conn->error);
    }

    $stmt->bind_param("sss", $name, $email, $hashedPassword);
    $stmt->execute();

    if ($stmt->error) {
        die("Error executing SQL query: " . $stmt->error);
    }

    if ($stmt->affected_rows > 0) {
        echo "Registration successful!";
    } else {
        echo "Error: Registration failed";
    }
}

$conn->close();
?>
