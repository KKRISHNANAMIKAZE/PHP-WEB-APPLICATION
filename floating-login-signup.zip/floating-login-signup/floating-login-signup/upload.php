<?php
// upload.php

session_start(); // Start the session

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_FILES["eventFolders"])) {
        // Handle event folders upload logic here
        $eventName = $_POST["eventName"];
        $eventDate = $_POST["eventDate"];

        // Sanitize event name to ensure it is a valid folder name
        $eventName = preg_replace('/[^a-zA-Z0-9]/', '', $eventName);

        // Get the logged-in user's custom ID from the session
        $loggedInCustomId = isset($_SESSION['custom_id']) ? $_SESSION['custom_id'] : null;

        if ($loggedInCustomId) {
            // Create a folder in the Downloads directory with the sanitized event name and custom ID
            $downloadsPath = "C:/Users/artha/Downloads"; // Change this path to your Downloads path
            $folderPath = "$downloadsPath/user_$loggedInCustomId/$eventName";

            if (!file_exists($folderPath)) {
                if (mkdir($folderPath, 0777, true)) {
                    foreach ($_FILES["eventFolders"]["tmp_name"] as $key => $tmpFolder) {
                        $folderName = basename($_FILES["eventFolders"]["name"][$key]);
                        $destination = $folderPath . "/" . $folderName;

                        if (move_uploaded_file($tmpFolder, $destination)) {
                            // Successfully moved the folder
                        } else {
                            // Failed to move the folder
                            echo "Error moving folder.";
                            exit;
                        }
                    }

                    echo "Folders uploaded successfully to folder: $folderPath";
                } else {
                    echo "Error creating folder.";
                }
            } else {
                echo "Folder already exists. Choose a different event name.";
            }
        } else {
            echo "User not logged in."; // Handle the case when the user is not logged in
        }
    }
    // Close the outermost if statement
}

session_write_close(); // Close the session
?>
